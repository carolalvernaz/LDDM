package com.example.fitlab

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
